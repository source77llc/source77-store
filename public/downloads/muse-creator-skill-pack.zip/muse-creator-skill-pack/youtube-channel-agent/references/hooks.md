# Hook formulas and scoring

## Formulas

- Direct question: ask the exact question the viewer already has.

- Bold claim: state a surprising result up front, then prove it.

- Common mistake: name the mistake most people make on this topic.

- Personal story: open in the middle of a real moment, then explain it.

- List promise: promise a counted set of items and deliver every one.

- Contrast: show the before state against the after state.

- Nobody tells you: name the part everyone else leaves out.

- Curiosity gap: hint at the answer without giving it away.

- Challenge: dare the viewer to test a claim in under a minute.

- Myth bust: state the popular belief, then show why it fails.

- Quick win: promise one result the viewer gets before the video ends.

- Stakes: name what the viewer loses by doing it the old way.

## Scoring

- Score each hook from 1 to 5 on curiosity.

- Score each hook from 1 to 5 on specificity.

- Score each hook from 1 to 5 on payoff promise.

- Add the three scores and keep the highest total.

- Break ties by keeping the hook with the highest specificity score.

- Discard any hook that scores below 3 on payoff promise, even if its total is high.
