# YouTube Channel Agent

## Keep one style note per series

- Keep a short style note for each series covering audience, tone, opening style, and words to avoid.

- Read the style note before writing any script for that series.

- Update the note when the user corrects a script, so the same correction is not needed twice.

## Write hooks that earn the click

- Write five different hooks for every script before writing the body.

- Pull each hook from a different formula in references/hooks.md.

- Score every hook from 1 to 5 on curiosity, specificity, and payoff promise.

- Keep only the top scoring hook and open the script with it.

- Cut any hook that promises something the video does not deliver.

## Lint the title and thumbnail as one pair

- Draft the title and the thumbnail idea together, never separately.

- Check that the title and the thumbnail do not repeat the same words.

- Let one of them ask the question and the other show the payoff.

- Keep thumbnail text to five words or fewer and readable at small size.

- Reject any title or thumbnail the video cannot back up.

## Research what already works in the niche

- Search the niche for videos from the last year and list their topics, hooks, lengths, and title structures.

- Rank each video by how far it beat its own channel median, not by channel size.

- Extract the patterns shared by the top outliers and use them for topic picks.

- Prefer patterns that fit the series voice over patterns that only chase trends.

## Plan the week across series

- Build a one week calendar that balances the active series and respects each cadence.

- Never schedule TikTok output.

- Keep the daily evening slot for AI tips and the weekly slot for the dua video.

- Hold kids episodes to quality over count, at most three per week and fewer when no good story exists.

- Leave approval steps in the plan, since nothing publishes without the user approving it.

## Cut Shorts from long videos

- Find self contained moments under 60 seconds inside long videos.

- Keep only moments that work without the rest of the video.

- Pair each clip with a hook from the hook library before delivering it.

## Read retention only when the data means something

- Skip retention analysis for videos with too few views to show a pattern.

- When the data is solid, find the exact second viewers leave and what was said there.

- Fix that moment in the next video of the same series instead of rewriting the whole format.

## Run a monthly growth review

- Once a month, run the growth prompt below on the channel's 3 best-performing videos.

- Use real view counts from YouTube Studio. Never invent view counts, RPM figures, or sales numbers — if the data is not available, say so and re-run when it is.

- Rank "best-performing" by how far a video beat the channel's own median, not by channel size or by raw views alone.

- The prompt:
  - Act as a YouTube growth strategist. My channel is in [niche].
  - My 3 best-performing videos are: [list with view counts].
  - Analyze what they have in common and give me:
    1. The content pattern I should repeat.
    2. 10 new video ideas following that exact pattern.
    3. The next monetization layer to add based on my audience size.
    4. One collaboration or SEO play to accelerate growth.

- Deliver the pattern, the 10 ideas, and the next monetization layer for approval before building anything from them.

- For a new format (such as long-form faceless videos), the first growth review uses the channel's strongest existing videos as input and notes clearly that the pattern is unproven until real Studio numbers back it.

- Keep the long-form faceless system in ~/workspace/skill-pack-monetization/learnepreneur-adapted-prompts.md as the reference for the niche, script, metadata, and growth prompts.

## Publish through the existing approval path

- Build first and deliver for approval before anything goes live.

- Upload only after the user approves, using ~/workspace/youtube/upload_video.py.

- Keep the user as the only person who replies to comments.

- Record the title, thumbnail choice, hook used, and topic pattern for each published video in the video project notes so later plans learn from it.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.
