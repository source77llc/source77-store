# Muse Creator Skill Pack — Package README

**Version:** 1.0 — November 2026
**Status:** Ready to post. NOT posted anywhere yet. Price: $25 (confirmed by Khalid).

## What this is

A digital download product: two custom Muse skills + a setup guide. Built and tested on a real daily video channel (Iraqintexas on YouTube, AI-tips reels on Instagram and Facebook) before being sold.

## What's inside

| File | What it is |
|---|---|
| `youtube-channel-agent/SKILL.md` | Skill 1 — YouTube planning: 5 scored hooks per script, title + thumbnail pairing, niche outlier research, weekly plan, Shorts from long videos, retention fixes, approval-gated publishing |
| `youtube-channel-agent/references/hooks.md` | Hook formula library for Skill 1 |
| `youtube-channel-agent/skill.yaml` | Skill info file — do not edit |
| `reel-builder/SKILL.md` | Skill 2 — Reel building: one topic line in, finished reel out, voice-first, Arabic caption font pre-check, self-check pass, approval-gated posting, never TikTok |
| `reel-builder/references/patterns.md` | Scene pattern library for Skill 2 |
| `reel-builder/skill.yaml` | Skill info file — do not edit |
| `setup-guide.md` | Plain-words install + first video plan + first reel + troubleshooting |
| `sales-page-copy.md` | Sales page text for the store listing (DRAFT — price confirmed at $25) |
| `README.md` | This file |

## Source of the skills

The two skills were written for Khalid's own channel in October 2026 and proven there first, per his plan: prove on his own channel, then monetize. The skill files in this package are exact copies of the working skills — verified identical, not rewritten.

## Source of the sales strategy

Jimmy Reilly's free prompt materials (free PDFs + free prompt pages on jimmyreilly.com), adapted to Muse. Full adapted prompt set + product outline: `../jimmy-reilly-adapted-prompts.md`. No paid course content was bought or used. Reilly's income claims are his marketing claims and are not repeated anywhere in this package.

## Before this goes live (Khalid must confirm)

1. **Price** — $25 confirmed by Khalid.
2. **Product name** — "Muse Creator Skill Pack" proposed. Confirm or change.
3. **Language** — sales page is English. Confirm whether an Arabic version is also needed.
4. **Store listing** — the website agent (other agent) lists it on source77llc.com once the above are confirmed. Nothing is posted by Arlo.

## Handoff note for the website agent

- Product: "Muse Creator Skill Pack" — digital download (ZIP of this package folder).
- Files to list: the two skill folders + setup guide. The sales-page-copy.md file is the listing text; README.md is internal, do not include it in the customer download (or include it — Khalid's call).
- Price: $25 confirmed by Khalid — ready to publish.
- Where: a product page on source77llc.com, linked from the store. Use the headline, sub-headline, "What's inside" list, and CTA from sales-page-copy.md.
- Delivery: instant download after purchase (ZIP). Confirm the store's download setup with Khalid.
