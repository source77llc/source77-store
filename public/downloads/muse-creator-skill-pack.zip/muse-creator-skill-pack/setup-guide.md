# Muse Creator Skill Pack — Setup Guide

**What this pack is:** two skills that turn Muse into your YouTube planning and video-making helper. You don't need to code. You don't need to be on camera. You just talk to Muse.

**What you need:** a Muse account. That's it.

---

## Step 1 — Install the skills (5 minutes)

1. Download the pack and unzip it. You will see two folders:
   - `youtube-channel-agent`
   - `reel-builder`
2. Muse keeps custom skills in a skills folder. Ask your Muse this exact question:
   > "Where do I put a custom skill on this setup?"
   It will show you the folder path.
3. Copy both folders into that folder. Don't rename them. Don't open the files inside and change anything.
4. Done. The skills are installed.

**How to check it worked:** ask your Muse:
> "What skills do you have?"
It should list "YouTube Channel Agent" and "Reel Builder". If it doesn't, close Muse and open it again, then ask once more.

---

## Step 2 — Your first video plan (YouTube Channel Agent)

This skill plans your videos, writes hooks, and pairs titles with thumbnails.

**Say this to Muse:**
> "Use the YouTube Channel Agent skill. My channel is about [your topic]. Plan next week's videos for me."

**What happens next:**
1. Muse will ask you a few questions (your channel, your audience, how many videos a week). Answer them.
2. Muse writes 5 different hooks for each video idea and scores them — it keeps only the best one.
3. Muse drafts the title AND the thumbnail idea together (one asks the question, the other shows the payoff).
4. Muse gives you a one-week calendar.

**Say yes or no to each video.** Nothing is final until you approve it. Muse will not post anything on its own.

**Tips:**
- If a hook promises something the video doesn't deliver, tell Muse to cut it. It will.
- If you want Shorts from a long video, say: "Cut Shorts from this video" and paste the video script or link. Muse finds the best moments under 60 seconds and pairs each with a hook.

---

## Step 3 — Your first reel (Reel Builder)

This skill turns one topic line into a finished short reel.

**Say this to Muse:**
> "Use the Reel Builder skill. My topic is: [one line — for example: 'a free tool that turns text into a song']"

**What happens next:**
1. Muse writes a short script (under 60 seconds) that opens with a strong hook.
2. Muse builds the scenes and the captions.
3. Muse checks every caption character against the font before rendering, so Arabic text never shows as broken boxes.
4. Muse watches the finished reel once, fixes weak moments, and shows it to you.

**Your voice:** if you want your real voice in the reel, send Muse a voice recording of the script. If you don't send one, Muse uses a clear AI voice instead. Your voice always comes first when you provide it.

**Approve before posting.** Muse shows you the reel and the caption first. Only when you say "post it" does anything go live. You are the only person who replies to comments.

**Where it posts:** Instagram, Facebook, and YouTube — whichever you choose. It never makes anything for TikTok.

---

## Step 4 — Your weekly routine (once it's running)

- **Once a week:** ask for next week's video plan.
- **Every day:** give Muse one topic line, get one finished reel back, approve it, post it.
- **After each video:** tell Muse what worked and what didn't. It keeps a style note for each series, so it stops repeating mistakes you already corrected.

---

## The rules the skills follow (so you know what to expect)

- Nothing publishes without your approval. Ever.
- You reply to comments yourself — Muse never pretends to be you.
- Hooks never promise what the video doesn't deliver.
- Titles and thumbnails are checked as a pair before you see them.
- No TikTok output, ever.
- Your voice is never cloned or changed — recordings are only cleaned up (less noise, no dead air).

---

## Troubleshooting — the 5 most common beginner mistakes

**1. "Muse says it can't find the skill."**
You copied the folders to the wrong place, or Muse needs a restart. Ask Muse where the skills folder is, move the folders there, and restart Muse.

**2. "The hooks all sound the same."**
Give Muse more detail. Instead of "videos about cooking", say "quick dinner videos for busy parents who get home at 6pm and have 20 minutes". Specific input = specific hooks.

**3. "The title and the thumbnail say the same thing."**
Tell Muse: "The title and thumbnail repeat each other — make one ask the question and the other show the payoff." That's the rule in the skill; sometimes it needs a nudge.

**4. "The Arabic captions show as boxes."**
This should not happen — the skill checks every character against the font before rendering. If you see boxes, tell Muse exactly which words broke. It will swap the punctuation and re-render.

**5. "Muse posted something I didn't approve."**
It shouldn't — approval is built into both skills. If anything ever posts without your clear "yes", tell Muse immediately what happened so it can be fixed. And never approve a post you haven't actually watched or read.

---

## What is inside the pack (file list)

- `youtube-channel-agent/SKILL.md` — the YouTube planning skill
- `youtube-channel-agent/references/hooks.md` — the hook formula library
- `youtube-channel-agent/skill.yaml` — skill info file (don't edit)
- `reel-builder/SKILL.md` — the reel building skill
- `reel-builder/references/patterns.md` — the scene pattern library
- `reel-builder/skill.yaml` — skill info file (don't edit)
- `setup-guide.md` — this file
- `sales-page-copy.md` — the sales page text (for the store listing)
- `README.md` — what's in the pack

**Support:** if a skill doesn't work as described, contact the seller through the store. Do not edit the SKILL.md files — the skills are tested as they are, and edits can break them.

---

*Version 1.0 — November 2026. Built and tested on a real daily video channel (Iraqintexas on YouTube, AI-tips reels on Instagram and Facebook) before being sold.*
