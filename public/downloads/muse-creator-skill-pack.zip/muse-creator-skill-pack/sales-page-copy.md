# Sales Page Copy — Muse Creator Skill Pack

**Status: Price confirmed at $25 by Khalid. Final wording to confirm before posting.**
**Price: $25 (confirmed by Khalid).**

---

## Product title

**Muse Creator Skill Pack — Plan, Script & Post YouTube Videos Without Getting on Camera**

## Short description (for the store listing)

Two copy/paste Muse skills that plan your week, write scored hooks, pair titles with thumbnails, and turn one topic line into a finished reel. You approve every post. No editor. No camera. No guesswork.

## Headline (sales page)

**Post a Week of YouTube Videos Without Getting on Camera**

## Sub-headline

Two copy/paste Muse skills do the planning, the hooks, the titles, and the reels. You approve every post. No editor. No camera. No guesswork.

## What's inside

- ✓ **YouTube Channel Agent** — writes 5 hooks per script and keeps only the best one (scored 1–5 on curiosity, specificity, and payoff). Pairs title + thumbnail so one asks the question and the other shows the payoff. Researches your niche for outlier videos that beat their own channel's average. Plans your week. Cuts Shorts under 60 seconds from long videos. Fixes the exact second viewers leave.
- ✓ **Reel Builder** — one topic line in, finished reel out. Opens with a strong hook, builds scenes with code (fast and cheap), pre-checks every Arabic caption character against the font so text never breaks, and self-checks the finished reel before showing it to you. Your real voice first; AI voice only as fallback.
- ✓ **Setup guide** — plain-words install, your first video plan, your first reel, and the 5 most common beginner mistakes (with fixes).
- ✓ **Hook library** (`hooks.md`) — the hook formulas behind every script.
- ✓ **Scene pattern library** (`patterns.md`) — the scene patterns behind every reel.
- ✓ **Approval-gated publishing** — nothing posts without your say. You are the only person who replies to comments.

## Who it's for

- Beginner YouTube creators who want to post consistently without getting on camera or hiring an editor.
- Arabic-speaking creators in the US and Iraq making faceless videos — the reel builder's hook format and caption checks are built for Arabic.
- Small creators who have ideas but no system: no plan, no hooks, no thumbnails, no posting routine.

## Who it's NOT for

- Creators who want fully automatic posting with no review — every post needs your approval by design.
- TikTok creators — the pack never makes TikTok output.
- Anyone who wants a "get rich quick" trick — this is a workflow, tested on a real channel, not a promise of views or income.

## How it works (3 steps)

1. **Install** — copy two folders into your Muse skills folder (5 minutes, setup guide walks you through it).
2. **Plan** — ask Muse for next week's videos. It writes the hooks, titles, and thumbnails.
3. **Post** — give Muse one topic line a day, get a finished reel back, approve it, post it.

## Proof

Built and tested on a real daily video channel before being sold — AI-tips reels (Instagram + Facebook) and the Iraqintexas YouTube channel, including daily videos, Shorts cut from long videos, and a weekly series. The skills were refined from real corrections on real videos.

## Price

**$25** — one-time payment. Instant download. Both skills + setup guide + hook library + pattern library included.

## FAQ (draft — confirm answers with Khalid before posting)

**Do I need to know how to code?**
No. You copy two folders and talk to Muse in plain words.

**Does it work in Arabic?**
Yes. The reel builder was built for Arabic AI-tips reels — Arabic hooks, Arabic captions with a font pre-check, and voiceover in your real voice.

**Will it post videos without asking me?**
No. Nothing publishes without your approval. That rule is built into both skills.

**What if a skill doesn't work?**
Contact the seller through the store. Don't edit the skill files — they are tested as they are.

**Do I need anything besides Muse?**
No. A Muse account is all you need.

## Call to action

**[ Send Me the Skill Pack — $25 ]**

---

## Alternate headlines (for testing)

1. "The Faceless Creator's Skill Pack: Plan, Script, and Post Daily Videos With Muse — No Editor, No Camera, No Guesswork"
2. "One Line In, Finished Reel Out: The Muse Skill Pack That Turns a Topic Into a Posted Video"
3. "Your YouTube Channel, Run by Two Skills: Scored Hooks, Paired Titles, Weekly Plans — You Approve, It Posts"
4. "Stop Writing Scripts From Scratch: The Tested Muse Workflow Behind a Real Daily Video Channel"

## Alternate hooks (for ads / social posts)

- "New Muse skill pack plans, scripts and posts a week of YouTube videos — without getting on camera, without hiring an editor, using copy/paste prompts."
- "Grow on YouTube WITHOUT getting on camera — the same two skills behind a real channel's daily videos, now as a copy/paste pack."
- "Stop staring at a blank script. One line in, finished reel out — hooks scored, captions checked, approval before anything posts."

---

*Notes for the website agent: this is copy only — no page built yet. The store listing needs: product title, short description, price ($25, confirmed by Khalid), the "What's inside" list, and a download link to the pack files. The sales page headline, sub-headline, bullets, and CTA above are the page copy. Price is confirmed. Do not publish until Khalid confirms the final wording.*
