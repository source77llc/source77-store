# Scene and caption patterns

## Hook patterns

- Direct question: ask the exact question the viewer already has.

- Bold claim: state a surprising result up front, then prove it.

- Common mistake: name the mistake most people make on this topic.

- Personal story: open in the middle of a real moment, then explain it.

- List promise: promise a counted set of items and deliver every one.

- Contrast: show the before state against the after state.

- Curiosity gap: hint at the answer without giving it away.

- Quick win: promise one result the viewer gets before the video ends.

## Pacing rules

- Change the visual every 2 to 4 seconds.

- Put the payoff in the first 3 seconds.

- Keep total length under 60 seconds.

## Caption animation rules

- Animate captions word by word in sync with the voice.

- Keep captions to a few words per screen.

- Use high contrast colors and a large readable size.

- Pre-check every character against the font, per the skill.
