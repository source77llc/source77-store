# Reel Builder

## Start from one line

- Take one topic line from the user and expand it into a short script.

- Keep the script under 60 seconds of spoken words.

- Open with a hook in his HOOK FORMAT (Oct 31): short punchy Arabic hook (pain or saving) + 2–3 sentence demo + CTA with a one-word comment keyword ("اكتب كلمة <keyword> في الكومنتات وأرسلك الرابط"). He replies to comments himself and sends the link. Focus on FREE tools for a US Arabic-speaking audience.

## Use the voice the user gave you

- Use the user's real voice recording first when one exists for the script.

- Fall back to AI Voice 1 only when no recording exists and the script is not held.

- Never burn a held script with the AI voice.

- Clean the audio by normalizing, denoising, and trimming dead air, without cloning or changing identity.

## Build scenes with code, not video models

- Assemble scenes from the pattern library in references/patterns.md.

- Animate captions and scene changes with code so the output stays fast and cheap.

- Vary the hook style, pacing, and caption motion across reels so they do not all look alike.

## Check captions against the font before rendering

- List every unique character in the captions before building the video.

- Render each character with the chosen font and compare it against a tofu reference.

- Replace any character the font lacks with Arabic script punctuation or drop the mark.

- Never render a video with unchecked captions.

## Review the reel and fix weak moments

- Watch the rendered reel once end to end before delivering it.

- Check hook strength, caption readability, timing, and audio clarity.

- Fix any weak moment and re-render before delivery.

- Deliver only a reel that passes every check.

## Post only with approval and only on allowed platforms

- Deliver the reel and caption for approval before posting anything.

- Post AI tips videos to Instagram only, mixed content to the Karada page, and all video projects to YouTube.

- Never produce output for TikTok.

- Add the cross links to new posts and never backfill old posts.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.
